Each line of the files follows the following format:
user_ID	POI_ID	coordinate	checkin_time(hour:min)	date_id

p.s., check-ins made on the same date have the same date_id
*****************************************************************************************************

This data is used in the experiments of the following paper:
Quan Yuan, Gao Cong, Zongyang Ma, Aixin Sun, Nadia Magnenat-Thalmann: Time-aware point-of-interest recommendation. SIGIR 2013: 363-372

Please kindly cite the paper if you choose to use the data.